﻿namespace AdministratorComander
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.backpanel = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.licolb = new System.Windows.Forms.Label();
            this.statuslb = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.fotobt = new System.Windows.Forms.Button();
            this.pb = new System.Windows.Forms.PictureBox();
            this.merinfotb = new System.Windows.Forms.TextBox();
            this.infolblb = new System.Windows.Forms.Label();
            this.datatb = new System.Windows.Forms.TextBox();
            this.datalb = new System.Windows.Forms.Label();
            this.mernametb = new System.Windows.Forms.TextBox();
            this.mernamelb = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.eventpanel = new System.Windows.Forms.Panel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.inputpn = new System.Windows.Forms.Panel();
            this.escbt = new System.Windows.Forms.Button();
            this.contactstb = new System.Windows.Forms.TextBox();
            this.numlb = new System.Windows.Forms.Label();
            this.agreelb = new System.Windows.Forms.Label();
            this.acceptbt = new System.Windows.Forms.Button();
            this.infotb = new System.Windows.Forms.TextBox();
            this.worktb = new System.Windows.Forms.TextBox();
            this.agetb = new System.Windows.Forms.TextBox();
            this.nametb = new System.Windows.Forms.TextBox();
            this.infolb = new System.Windows.Forms.Label();
            this.worklb = new System.Windows.Forms.Label();
            this.agelb = new System.Windows.Forms.Label();
            this.Namelb = new System.Windows.Forms.Label();
            this.inputlb = new System.Windows.Forms.Label();
            this.outputpn = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.salarytb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.gh = new System.Windows.Forms.Label();
            this.paybt = new System.Windows.Forms.Button();
            this.paytb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3.SuspendLayout();
            this.backpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.inputpn.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.backpanel);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 424);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Анонс события";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // backpanel
            // 
            this.backpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(253)))), ((int)(((byte)(246)))));
            this.backpanel.Controls.Add(this.comboBox1);
            this.backpanel.Controls.Add(this.licolb);
            this.backpanel.Controls.Add(this.statuslb);
            this.backpanel.Controls.Add(this.button1);
            this.backpanel.Controls.Add(this.fotobt);
            this.backpanel.Controls.Add(this.pb);
            this.backpanel.Controls.Add(this.merinfotb);
            this.backpanel.Controls.Add(this.infolblb);
            this.backpanel.Controls.Add(this.datatb);
            this.backpanel.Controls.Add(this.datalb);
            this.backpanel.Controls.Add(this.mernametb);
            this.backpanel.Controls.Add(this.mernamelb);
            this.backpanel.Location = new System.Drawing.Point(6, 6);
            this.backpanel.Name = "backpanel";
            this.backpanel.Size = new System.Drawing.Size(778, 410);
            this.backpanel.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(496, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 19;
            // 
            // licolb
            // 
            this.licolb.AutoSize = true;
            this.licolb.Location = new System.Drawing.Point(506, 65);
            this.licolb.Name = "licolb";
            this.licolb.Size = new System.Drawing.Size(111, 13);
            this.licolb.TabIndex = 18;
            this.licolb.Text = "Ответственное лицо";
            // 
            // statuslb
            // 
            this.statuslb.AutoSize = true;
            this.statuslb.Location = new System.Drawing.Point(542, 352);
            this.statuslb.Name = "statuslb";
            this.statuslb.Size = new System.Drawing.Size(0, 13);
            this.statuslb.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(242)))), ((int)(((byte)(206)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(542, 260);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 85);
            this.button1.TabIndex = 16;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // fotobt
            // 
            this.fotobt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(242)))), ((int)(((byte)(206)))));
            this.fotobt.Location = new System.Drawing.Point(542, 166);
            this.fotobt.Name = "fotobt";
            this.fotobt.Size = new System.Drawing.Size(75, 87);
            this.fotobt.TabIndex = 15;
            this.fotobt.Text = "Выбрать фото";
            this.fotobt.UseVisualStyleBackColor = false;
            this.fotobt.Click += new System.EventHandler(this.fotobt_Click);
            // 
            // pb
            // 
            this.pb.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pb.Location = new System.Drawing.Point(162, 166);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(374, 179);
            this.pb.TabIndex = 14;
            this.pb.TabStop = false;
            // 
            // merinfotb
            // 
            this.merinfotb.Location = new System.Drawing.Point(268, 81);
            this.merinfotb.Multiline = true;
            this.merinfotb.Name = "merinfotb";
            this.merinfotb.Size = new System.Drawing.Size(221, 68);
            this.merinfotb.TabIndex = 13;
            this.merinfotb.TextChanged += new System.EventHandler(this.merinfotb_TextChanged);
            // 
            // infolblb
            // 
            this.infolblb.AutoSize = true;
            this.infolblb.Location = new System.Drawing.Point(346, 65);
            this.infolblb.Name = "infolblb";
            this.infolblb.Size = new System.Drawing.Size(57, 13);
            this.infolblb.TabIndex = 12;
            this.infolblb.Text = "Описание";
            this.infolblb.Click += new System.EventHandler(this.infolblb_Click);
            // 
            // datatb
            // 
            this.datatb.Location = new System.Drawing.Point(162, 129);
            this.datatb.Name = "datatb";
            this.datatb.Size = new System.Drawing.Size(100, 20);
            this.datatb.TabIndex = 11;
            // 
            // datalb
            // 
            this.datalb.AutoSize = true;
            this.datalb.Location = new System.Drawing.Point(192, 113);
            this.datalb.Name = "datalb";
            this.datalb.Size = new System.Drawing.Size(33, 13);
            this.datalb.TabIndex = 10;
            this.datalb.Text = "Дата";
            // 
            // mernametb
            // 
            this.mernametb.Location = new System.Drawing.Point(162, 81);
            this.mernametb.Name = "mernametb";
            this.mernametb.Size = new System.Drawing.Size(100, 20);
            this.mernametb.TabIndex = 9;
            // 
            // mernamelb
            // 
            this.mernamelb.AutoSize = true;
            this.mernamelb.Location = new System.Drawing.Point(180, 65);
            this.mernamelb.Name = "mernamelb";
            this.mernamelb.Size = new System.Drawing.Size(57, 13);
            this.mernamelb.TabIndex = 8;
            this.mernamelb.Text = "Название";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.eventpanel);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "События";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // eventpanel
            // 
            this.eventpanel.AutoScroll = true;
            this.eventpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(253)))), ((int)(((byte)(246)))));
            this.eventpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eventpanel.Location = new System.Drawing.Point(3, 3);
            this.eventpanel.Name = "eventpanel";
            this.eventpanel.Size = new System.Drawing.Size(786, 418);
            this.eventpanel.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.inputpn);
            this.tabPage1.Controls.Add(this.outputpn);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Работники";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // inputpn
            // 
            this.inputpn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(253)))), ((int)(((byte)(246)))));
            this.inputpn.Controls.Add(this.salarytb);
            this.inputpn.Controls.Add(this.label1);
            this.inputpn.Controls.Add(this.escbt);
            this.inputpn.Controls.Add(this.contactstb);
            this.inputpn.Controls.Add(this.numlb);
            this.inputpn.Controls.Add(this.agreelb);
            this.inputpn.Controls.Add(this.acceptbt);
            this.inputpn.Controls.Add(this.infotb);
            this.inputpn.Controls.Add(this.worktb);
            this.inputpn.Controls.Add(this.agetb);
            this.inputpn.Controls.Add(this.nametb);
            this.inputpn.Controls.Add(this.infolb);
            this.inputpn.Controls.Add(this.worklb);
            this.inputpn.Controls.Add(this.agelb);
            this.inputpn.Controls.Add(this.Namelb);
            this.inputpn.Controls.Add(this.inputlb);
            this.inputpn.Dock = System.Windows.Forms.DockStyle.Right;
            this.inputpn.Location = new System.Drawing.Point(519, 3);
            this.inputpn.Name = "inputpn";
            this.inputpn.Size = new System.Drawing.Size(270, 418);
            this.inputpn.TabIndex = 3;
            // 
            // escbt
            // 
            this.escbt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(242)))), ((int)(((byte)(206)))));
            this.escbt.Location = new System.Drawing.Point(177, 17);
            this.escbt.Name = "escbt";
            this.escbt.Size = new System.Drawing.Size(75, 23);
            this.escbt.TabIndex = 17;
            this.escbt.Text = "Выход";
            this.escbt.UseVisualStyleBackColor = false;
            this.escbt.Click += new System.EventHandler(this.escbt_Click);
            // 
            // contactstb
            // 
            this.contactstb.Location = new System.Drawing.Point(91, 97);
            this.contactstb.Name = "contactstb";
            this.contactstb.Size = new System.Drawing.Size(161, 20);
            this.contactstb.TabIndex = 16;
            // 
            // numlb
            // 
            this.numlb.AutoSize = true;
            this.numlb.Location = new System.Drawing.Point(20, 100);
            this.numlb.Name = "numlb";
            this.numlb.Size = new System.Drawing.Size(56, 13);
            this.numlb.TabIndex = 15;
            this.numlb.Text = "Контакты";
            // 
            // agreelb
            // 
            this.agreelb.AutoSize = true;
            this.agreelb.Location = new System.Drawing.Point(23, 361);
            this.agreelb.Name = "agreelb";
            this.agreelb.Size = new System.Drawing.Size(0, 13);
            this.agreelb.TabIndex = 14;
            // 
            // acceptbt
            // 
            this.acceptbt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(242)))), ((int)(((byte)(206)))));
            this.acceptbt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.acceptbt.Location = new System.Drawing.Point(192, 355);
            this.acceptbt.Name = "acceptbt";
            this.acceptbt.Size = new System.Drawing.Size(60, 60);
            this.acceptbt.TabIndex = 13;
            this.acceptbt.Text = "+";
            this.acceptbt.UseVisualStyleBackColor = false;
            this.acceptbt.Click += new System.EventHandler(this.acceptbt_Click_1);
            // 
            // infotb
            // 
            this.infotb.Location = new System.Drawing.Point(23, 223);
            this.infotb.Multiline = true;
            this.infotb.Name = "infotb";
            this.infotb.Size = new System.Drawing.Size(229, 131);
            this.infotb.TabIndex = 12;
            // 
            // worktb
            // 
            this.worktb.Location = new System.Drawing.Point(91, 150);
            this.worktb.Name = "worktb";
            this.worktb.Size = new System.Drawing.Size(161, 20);
            this.worktb.TabIndex = 11;
            // 
            // agetb
            // 
            this.agetb.Location = new System.Drawing.Point(91, 125);
            this.agetb.Name = "agetb";
            this.agetb.Size = new System.Drawing.Size(161, 20);
            this.agetb.TabIndex = 10;
            // 
            // nametb
            // 
            this.nametb.Location = new System.Drawing.Point(91, 70);
            this.nametb.Name = "nametb";
            this.nametb.Size = new System.Drawing.Size(161, 20);
            this.nametb.TabIndex = 9;
            // 
            // infolb
            // 
            this.infolb.AutoSize = true;
            this.infolb.Location = new System.Drawing.Point(20, 198);
            this.infolb.Name = "infolb";
            this.infolb.Size = new System.Drawing.Size(116, 13);
            this.infolb.TabIndex = 8;
            this.infolb.Text = "Краткая информация";
            // 
            // worklb
            // 
            this.worklb.AutoSize = true;
            this.worklb.Location = new System.Drawing.Point(20, 150);
            this.worklb.Name = "worklb";
            this.worklb.Size = new System.Drawing.Size(65, 13);
            this.worklb.TabIndex = 6;
            this.worklb.Text = "Должность";
            // 
            // agelb
            // 
            this.agelb.AutoSize = true;
            this.agelb.Location = new System.Drawing.Point(20, 128);
            this.agelb.Name = "agelb";
            this.agelb.Size = new System.Drawing.Size(49, 13);
            this.agelb.TabIndex = 4;
            this.agelb.Text = "Возраст";
            // 
            // Namelb
            // 
            this.Namelb.AutoSize = true;
            this.Namelb.Location = new System.Drawing.Point(20, 73);
            this.Namelb.Name = "Namelb";
            this.Namelb.Size = new System.Drawing.Size(34, 13);
            this.Namelb.TabIndex = 2;
            this.Namelb.Text = "ФИО";
            // 
            // inputlb
            // 
            this.inputlb.AutoSize = true;
            this.inputlb.Location = new System.Drawing.Point(20, 17);
            this.inputlb.Name = "inputlb";
            this.inputlb.Size = new System.Drawing.Size(72, 13);
            this.inputlb.TabIndex = 0;
            this.inputlb.Text = "Ввод данных";
            // 
            // outputpn
            // 
            this.outputpn.AutoScroll = true;
            this.outputpn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.outputpn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputpn.Dock = System.Windows.Forms.DockStyle.Left;
            this.outputpn.Location = new System.Drawing.Point(3, 3);
            this.outputpn.Name = "outputpn";
            this.outputpn.Size = new System.Drawing.Size(513, 418);
            this.outputpn.TabIndex = 2;
            this.outputpn.TabStop = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(253)))), ((int)(((byte)(246)))));
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.paytb);
            this.tabPage4.Controls.Add(this.paybt);
            this.tabPage4.Controls.Add(this.gh);
            this.tabPage4.Controls.Add(this.comboBox2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(792, 424);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Зарплата";
            // 
            // salarytb
            // 
            this.salarytb.Location = new System.Drawing.Point(91, 176);
            this.salarytb.Name = "salarytb";
            this.salarytb.Size = new System.Drawing.Size(161, 20);
            this.salarytb.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Зарплата";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(316, 165);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 0;
            // 
            // gh
            // 
            this.gh.AutoSize = true;
            this.gh.Location = new System.Drawing.Point(344, 149);
            this.gh.Name = "gh";
            this.gh.Size = new System.Drawing.Size(55, 13);
            this.gh.TabIndex = 1;
            this.gh.Text = "Работник";
            // 
            // paybt
            // 
            this.paybt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(242)))), ((int)(((byte)(206)))));
            this.paybt.Location = new System.Drawing.Point(337, 231);
            this.paybt.Name = "paybt";
            this.paybt.Size = new System.Drawing.Size(75, 23);
            this.paybt.TabIndex = 2;
            this.paybt.Text = "Изменить";
            this.paybt.UseVisualStyleBackColor = false;
            this.paybt.Click += new System.EventHandler(this.paybt_Click);
            // 
            // paytb
            // 
            this.paytb.Location = new System.Drawing.Point(317, 205);
            this.paytb.Name = "paytb";
            this.paytb.Size = new System.Drawing.Size(120, 20);
            this.paytb.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(334, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Новая зарплата";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.Name = "Form1";
            this.Text = "Admin";
            this.tabPage3.ResumeLayout(false);
            this.backpanel.ResumeLayout(false);
            this.backpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.inputpn.ResumeLayout(false);
            this.inputpn.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel backpanel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label licolb;
        private System.Windows.Forms.Label statuslb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button fotobt;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.TextBox merinfotb;
        private System.Windows.Forms.Label infolblb;
        private System.Windows.Forms.TextBox datatb;
        private System.Windows.Forms.Label datalb;
        private System.Windows.Forms.TextBox mernametb;
        private System.Windows.Forms.Label mernamelb;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel eventpanel;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel inputpn;
        private System.Windows.Forms.Button escbt;
        private System.Windows.Forms.TextBox contactstb;
        private System.Windows.Forms.Label numlb;
        private System.Windows.Forms.Label agreelb;
        private System.Windows.Forms.Button acceptbt;
        private System.Windows.Forms.TextBox infotb;
        private System.Windows.Forms.TextBox worktb;
        private System.Windows.Forms.TextBox agetb;
        private System.Windows.Forms.TextBox nametb;
        private System.Windows.Forms.Label infolb;
        private System.Windows.Forms.Label worklb;
        private System.Windows.Forms.Label agelb;
        private System.Windows.Forms.Label Namelb;
        private System.Windows.Forms.Label inputlb;
        private System.Windows.Forms.Panel outputpn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox salarytb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button paybt;
        private System.Windows.Forms.Label gh;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox paytb;
        private System.Windows.Forms.Label label2;
    }
}

